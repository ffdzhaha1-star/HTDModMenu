import SwiftUI

@main
struct HTDModMenuDemoApp: App {
    var body: some Scene {
        WindowGroup {
            DemoHostView()
        }
    }
}

struct DemoHostView: View {
    @State private var menuVisible = true

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.06, green: 0.10, blue: 0.18),
                                    Color(red: 0.02, green: 0.03, blue: 0.07)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 18) {
                Text("HẢI TẶC ĐẠI CHIẾN")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Bản menu demo độc lập — chức năng mô phỏng")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.65))
                Button(menuVisible ? "Ẩn menu nổi" : "Hiện menu nổi") {
                    menuVisible.toggle()
                }
                .buttonStyle(.borderedProminent)
            }

            if menuVisible {
                FloatingModMenu()
                    .transition(.opacity)
            }
        }
    }
}

struct FloatingModMenu: View {
    @State private var selectedTab = "Chức năng"
    @State private var speedOn = false
    @State private var autoRefresh = false
    @State private var recruitAuto = false
    @State private var showToast: String?

    private let tabs = ["Chức năng", "Tài nguyên", "Khác"]
    private let blue = Color(red: 0.12, green: 0.48, blue: 0.95)

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("☠  HTD MOD MENU")
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
                Button("×") {
                    showToast = "Dùng nút “Ẩn menu nổi” ở màn hình demo để đóng menu."
                }
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white.opacity(0.8))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(blue)

            HStack(spacing: 0) {
                ForEach(tabs, id: \.self) { tab in
                    Button(tab) { selectedTab = tab }
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(selectedTab == tab ? .white : .white.opacity(0.55))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(selectedTab == tab ? blue.opacity(0.32) : .clear)
                }
            }
            .background(Color.black.opacity(0.5))

            ScrollView {
                VStack(spacing: 9) {
                    if selectedTab == "Chức năng" {
                        toggleRow("Tăng tốc x1", isOn: $speedOn)
                        toggleRow("Shop tự làm mới", isOn: $autoRefresh)
                        toggleRow("Tự động chiêu mộ", isOn: $recruitAuto)
                        actionRow("Thám hiểm (demo)")
                        actionRow("Vòng quay (demo)")
                        actionRow("Nâng tướng (demo)")
                    } else if selectedTab == "Tài nguyên" {
                        valueRow("Kim cương", value: "Mô phỏng")
                        valueRow("Vàng", value: "Mô phỏng")
                        actionRow("Đậu thần (demo)")
                        Text("Các giá trị ở đây chỉ là minh họa, không thay đổi dữ liệu game.")
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.55))
                            .multilineTextAlignment(.center)
                            .padding(.top, 4)
                    } else {
                        actionRow("Thông tin bản demo")
                        actionRow("Đặt lại tùy chọn") {
                            speedOn = false
                            autoRefresh = false
                            recruitAuto = false
                            showToast = "Đã đặt lại tùy chọn demo."
                        }
                    }
                }
                .padding(12)
            }
            .frame(maxHeight: 330)

            if let showToast {
                Text(showToast)
                    .font(.caption)
                    .foregroundStyle(.white)
                    .padding(8)
                    .frame(maxWidth: .infinity)
                    .background(blue.opacity(0.75))
                    .onTapGesture { self.showToast = nil }
            }

            Text("DEMO • Không kết nối máy chủ game")
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(.white.opacity(0.45))
                .padding(.vertical, 8)
        }
        .frame(width: 300)
        .background(Color(red: 0.07, green: 0.08, blue: 0.11))
        .clipShape(RoundedRectangle(cornerRadius: 13))
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(blue.opacity(0.8), lineWidth: 1))
        .shadow(color: .black.opacity(0.45), radius: 18, y: 8)
        .position(x: UIScreen.main.bounds.width - 165, y: UIScreen.main.bounds.height * 0.48)
    }

    private func toggleRow(_ title: String, isOn: Binding<Bool>) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.white)
            Spacer()
            Toggle("", isOn: isOn)
                .labelsHidden()
                .tint(blue)
                .scaleEffect(0.82)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    private func actionRow(_ title: String, action: @escaping () -> Void = {}) -> some View {
        Button {
            action()
            if title != "Đặt lại tùy chọn" {
                showToast = "\(title): thao tác mô phỏng."
            }
        } label: {
            HStack {
                Text(title)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .bold))
            }
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(.white)
            .padding(.horizontal, 10)
            .padding(.vertical, 11)
            .background(Color.white.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }

    private func valueRow(_ title: String, value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.white)
            Spacer()
            Text(value).foregroundStyle(blue).fontWeight(.bold)
        }
        .font(.system(size: 13, weight: .semibold))
        .padding(10)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}
