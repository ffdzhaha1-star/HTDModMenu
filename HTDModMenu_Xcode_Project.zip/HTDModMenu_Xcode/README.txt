HTD Mod Menu Xcode project (standalone demo UI)

Open HTDModMenu.xcodeproj in Xcode on a Mac.
Select the HTDModMenu target, choose your iPhone, then:
- Signing & Capabilities: enable Automatically manage signing and select your Apple account/team.
- Press Run to install on device.
- To export IPA: Product > Archive, then Distribute App (Development/Ad Hoc as applicable).

This app is a standalone UI simulation; it does not modify Hải Tặc Đại Chiến or connect to its server.
A signed IPA requires Xcode on macOS and a valid signing identity/profile.
